.. :changelog:

History
-------

0.1.2 (2015-11-28)
---------------------

* Added Latin and Slovenian languages.



0.1.2 (2015-11-01)
---------------------

* Bump.


0.1.1 (2015-11-01)
---------------------

* Added languages files


0.1.0 (2015-11-01)
---------------------

* First release on PyPI.


