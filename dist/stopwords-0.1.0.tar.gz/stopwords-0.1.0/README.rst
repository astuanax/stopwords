===============================
stopwords
===============================

.. image:: https://img.shields.io/pypi/v/stopwords.svg
        :target: https://pypi.python.org/pypi/stopwords

.. image:: https://img.shields.io/travis/astuanax/stopwords.svg
        :target: https://travis-ci.org/astuanax/stopwords

.. image:: https://readthedocs.org/projects/stopwords/badge/?version=latest
        :target: https://readthedocs.org/projects/stopwords/?badge=latest
        :alt: Documentation Status


Stopwords removal 

* Free software: ISC license
* Documentation: https://stopwords.readthedocs.org.

Features
--------

* TODO

Credits
---------

Tools used in rendering this package:

*  Cookiecutter_
*  `cookiecutter-pypackage`_

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
