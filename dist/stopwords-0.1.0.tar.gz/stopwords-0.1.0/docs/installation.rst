============
Installation
============

At the command line::

    $ easy_install stopwords

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv stopwords
    $ pip install stopwords
