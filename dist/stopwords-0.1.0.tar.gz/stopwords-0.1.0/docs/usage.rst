========
Usage
========

To use stopwords in a project::

    import stopwords
