# -*- coding: utf-8 -*-

__author__ = 'Len Dierickx'
__email__ = 'len@astuanax.com'
__version__ = '0.1.1'
