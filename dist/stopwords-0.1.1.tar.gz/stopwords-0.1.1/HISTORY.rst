.. :changelog:

History
-------

0.1.0 (2015-01-11)
---------------------

* First release on PyPI.

0.1.1 (2015-01-11)
---------------------

* Added languages files
